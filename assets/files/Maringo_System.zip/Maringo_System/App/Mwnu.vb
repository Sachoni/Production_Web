﻿Public Class Mwnu
    Private Sub Mwnu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Show message
        MessageBox.Show("Hello")

        ' Open Form2
        Dim f2 As New Register_Student()
        f2.Show()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        ' Show message
        MessageBox.Show("Retun to Welcome")

        ' Open Form2
        Dim f2 As New Form1()
        f2.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        ' Show message
        MessageBox.Show("Open Sports Window")

        ' Open Form2
        Dim f2 As New Sports_form()
        f2.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Show message
        MessageBox.Show("Open Stuents Window")

        ' Open Form2
        Dim f2 As New Students_form()
        f2.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ' Show message
        MessageBox.Show("Open Marks Window")

        ' Open Form2
        Dim f2 As New Marks()
        f2.Show()
    End Sub
End Class