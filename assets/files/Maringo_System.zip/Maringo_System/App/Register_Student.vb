﻿Public Class Register_Student
    Private Sub Register_Student_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ' Show message
        MessageBox.Show("Retun to Menu")

        ' Open Form2
        Dim f2 As New Mwnu()
        f2.Show()
    End Sub
End Class