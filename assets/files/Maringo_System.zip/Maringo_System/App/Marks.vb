﻿Public Class Marks
    Private Sub Marks_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Show message
        MessageBox.Show("Retun to Welcome")

        ' Open Form2
        Dim f2 As New Mwnu()
        f2.Show()
    End Sub
End Class